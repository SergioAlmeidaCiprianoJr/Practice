Searching
=========

.. automodule:: anytree.search
