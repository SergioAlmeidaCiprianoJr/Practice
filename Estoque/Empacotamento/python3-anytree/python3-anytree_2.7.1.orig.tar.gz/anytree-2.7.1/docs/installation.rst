Installation
============

To install the `anytree` module run::

    pip install anytree

If you do not have write-permissions to the python installation, try::

    pip install anytree --user

.. _Tree: https://en.wikipedia.org/wiki/Tree_(data_structure)
