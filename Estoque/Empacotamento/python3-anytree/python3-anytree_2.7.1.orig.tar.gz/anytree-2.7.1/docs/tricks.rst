Tricks
======

.. toctree::
    tricks/readonly
    tricks/yaml
    tricks/multidim
