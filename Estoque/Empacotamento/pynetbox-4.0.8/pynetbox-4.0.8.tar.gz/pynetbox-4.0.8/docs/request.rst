Request
========

.. autoclass:: pynetbox.core.query.RequestError
  :members: